.. cmake-module:: ../../Modules/CheckCCompilerFlag.cmake
