#include "mongoc.h"

int
main (int argc, char **argv)
{
   bson_t *to_insert = BCON_NEW ("_id", BCON_INT32 (1));
   bson_t *selector = BCON_NEW ("_id", "{", "$gt", BCON_INT32 (0), "}");
   bson_t *update = BCON_NEW ("$set", "{", "x", BCON_INT32 (1), "}");
   const bson_t *next_doc;
   char *to_str;
   bson_error_t err = {0};
   mongoc_cursor_t *cursor;
   mongoc_client_t *client =
      mongoc_client_new ("mongodb://localhost:27017/?appname=example-update");
   mongoc_collection_t *coll =
      mongoc_client_get_collection (client, "db", "example_coll");

   mongoc_client_set_error_api (client, 2);
   /* insert a document */
   if (!mongoc_collection_insert_one (coll, to_insert, NULL, NULL, &err)) {
      fprintf (stderr, "insert failed: %s\n", err.message);
      return EXIT_FAILURE;
   }

   if (!mongoc_collection_update_one (
          coll, selector, update, NULL, NULL, &err)) {
      fprintf (stderr, "update failed %s\n", err.message);
      return EXIT_FAILURE;
   }

   to_str = bson_as_relaxed_extended_json (to_insert, NULL);
   printf ("inserted %s\n", to_str);
   bson_free (to_str);

   cursor = mongoc_collection_find_with_opts (coll, selector, NULL, NULL);
   BSON_ASSERT (mongoc_cursor_next (cursor, &next_doc));
   printf ("after update, collection has the following document:\n");

   to_str = bson_as_relaxed_extended_json (next_doc, NULL);
   printf ("%s\n", to_str);
   bson_free (to_str);

   BSON_ASSERT (mongoc_collection_drop (coll, NULL));

   bson_destroy (to_insert);
   bson_destroy (update);
   bson_destroy (selector);
   mongoc_collection_destroy (coll);
   mongoc_client_destroy (client);
   return EXIT_SUCCESS;
}
