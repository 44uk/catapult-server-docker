:man_page: mongoc_get_major_version

mongoc_get_major_version()
==========================

Synopsis
--------

.. code-block:: c

  int
  mongoc_get_major_version (void);

Returns
-------

The value of ``MONGOC_MAJOR_VERSION`` when libmongoc was compiled.

