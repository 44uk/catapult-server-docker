/**
*** Copyright (c) 2016-present,
*** Jaguar0625, gimre, BloodyRookie, Tech Bureau, Corp. All rights reserved.
***
*** This file is part of Catapult.
***
*** Catapult is free software: you can redistribute it and/or modify
*** it under the terms of the GNU Lesser General Public License as published by
*** the Free Software Foundation, either version 3 of the License, or
*** (at your option) any later version.
***
*** Catapult is distributed in the hope that it will be useful,
*** but WITHOUT ANY WARRANTY; without even the implied warranty of
*** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
*** GNU Lesser General Public License for more details.
***
*** You should have received a copy of the GNU Lesser General Public License
*** along with Catapult. If not, see <http://www.gnu.org/licenses/>.
**/

#include "mongo/src/MongoChainScoreProvider.h"
#include "mongo/src/MongoBulkWriter.h"
#include "mongo/src/MongoChainInfoUtils.h"
#include "catapult/model/ChainScore.h"
#include "mongo/tests/test/MapperTestUtils.h"
#include "mongo/tests/test/MongoTestUtils.h"
#include "tests/test/core/ThreadPoolTestUtils.h"
#include "tests/TestHarness.h"

using namespace bsoncxx::builder::stream;

namespace catapult { namespace mongo {

#define TEST_CLASS MongoChainScoreProviderTests

	namespace {
		class TestContext final : public test::PrepareDatabaseMixin {
		public:
			TestContext()
					: m_mongoContext(
							test::DefaultDbUri(),
							test::DatabaseName(),
							MongoBulkWriter::Create(test::DefaultDbUri(), test::DatabaseName(), test::CreateStartedIoServiceThreadPool(8)))
					, m_pScoreProvider(CreateMongoChainScoreProvider(m_mongoContext))
			{}

		public:
			ChainScoreProvider& chainScoreProvider() {
				return *m_pScoreProvider;
			}

		private:
			MongoStorageContext m_mongoContext;
			std::unique_ptr<ChainScoreProvider> m_pScoreProvider;
		};
	}

	namespace {
		void AssertDbScore(const model::ChainScore& expectedScore) {
			auto connection = test::CreateDbConnection();
			auto database = connection[test::DatabaseName()];

			auto cursor = database["chainInfo"].find({});
			ASSERT_EQ(1u, std::distance(cursor.begin(), cursor.end()));

			auto matchedDocument = database["chainInfo"].find_one({}).get();

			auto scoreLow = static_cast<uint64_t>(matchedDocument.view()["scoreLow"].get_int64().value);
			auto scoreHigh = static_cast<uint64_t>(matchedDocument.view()["scoreHigh"].get_int64().value);
			EXPECT_EQ(expectedScore, model::ChainScore(scoreHigh, scoreLow));
		}
	}

	TEST(TEST_CLASS, CanSaveScore) {
		// Arrange:
		TestContext context;
		model::ChainScore score(0x12345670, 0x89ABCDEF);

		// Act:
		context.chainScoreProvider().saveScore(score);

		// Assert:
		AssertDbScore(score);
	}

	TEST(TEST_CLASS, CanLoadScore) {
		// Arrange:
		TestContext context;
		model::ChainScore score(0x12345670, 0x89ABCDEF);
		context.chainScoreProvider().saveScore(score);

		// Act:
		auto result = context.chainScoreProvider().loadScore();

		// Assert:
		EXPECT_EQ(score, result);
	}

	TEST(TEST_CLASS, SaveScoreDoesNotOverwriteHeight) {
		// Arrange:
		TestContext context;
		model::ChainScore score(0x12345670, 0x89ABCDEF);

		// - set the height
		auto connection = test::CreateDbConnection();
		auto database = connection[test::DatabaseName()];
		auto heightDocument = document() << "$set" << open_document << "height" << static_cast<int64_t>(123) << close_document << finalize;
		SetChainInfoDocument(database, heightDocument.view());

		// Act:
		context.chainScoreProvider().saveScore(score);

		// Assert: the height is unchanged
		auto chainInfoDocument = GetChainInfoDocument(database);
		EXPECT_EQ(4u, test::GetFieldCount(chainInfoDocument.view()));
		EXPECT_EQ(123u, test::GetUint64(chainInfoDocument.view(), "height"));
	}
}}
