/**
*** Copyright (c) 2016-present,
*** Jaguar0625, gimre, BloodyRookie, Tech Bureau, Corp. All rights reserved.
***
*** This file is part of Catapult.
***
*** Catapult is free software: you can redistribute it and/or modify
*** it under the terms of the GNU Lesser General Public License as published by
*** the Free Software Foundation, either version 3 of the License, or
*** (at your option) any later version.
***
*** Catapult is distributed in the hope that it will be useful,
*** but WITHOUT ANY WARRANTY; without even the implied warranty of
*** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
*** GNU Lesser General Public License for more details.
***
*** You should have received a copy of the GNU Lesser General Public License
*** along with Catapult. If not, see <http://www.gnu.org/licenses/>.
**/

#include "src/SecretProofMapper.h"
#include "mongo/src/mappers/MapperUtils.h"
#include "plugins/txes/lock/src/model/SecretProofTransaction.h"
#include "mongo/tests/test/MongoTransactionPluginTestUtils.h"
#include "tests/test/LockMapperTestUtils.h"
#include "tests/test/LockTransactionUtils.h"

namespace catapult { namespace mongo { namespace plugins {

#define TEST_CLASS SecretProofMapperTests

	namespace {
		DEFINE_MONGO_TRANSACTION_PLUGIN_TEST_TRAITS_NO_ADAPT(SecretProof)
	}

	DEFINE_BASIC_MONGO_EMBEDDABLE_TRANSACTION_PLUGIN_TESTS(TEST_CLASS, model::Entity_Type_Secret_Proof)

	// region streamTransaction

	PLUGIN_TEST(CanMapSecretProofTransactionWithProof) {
		// Arrange:
		auto pTransaction = test::CreateSecretProofTransaction<TTraits>(123);
		auto pPlugin = TTraits::CreatePlugin();

		// Act:
		mappers::bson_stream::document builder;
		pPlugin->streamTransaction(builder, *pTransaction);
		auto view = builder.view();

		// Assert:
		EXPECT_EQ(3u, test::GetFieldCount(view));
		EXPECT_EQ(utils::to_underlying_type(pTransaction->HashAlgorithm), test::GetUint8(view, "hashAlgorithm"));
		EXPECT_EQ(pTransaction->Secret, test::GetHash512Value(view, "secret"));

		const auto* pProof = pTransaction->ProofPtr();
		const auto* pDbProof = test::GetBinary(view, "proof");
		EXPECT_EQ(test::ToHexString(pProof, pTransaction->ProofSize), test::ToHexString(pDbProof, pTransaction->ProofSize));
	}

	// endregion
}}}
