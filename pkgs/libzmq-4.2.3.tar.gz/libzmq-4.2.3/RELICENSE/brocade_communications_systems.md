## Brocade Communications Systems Inc.

This is a statement by Brocade Communications Systems Inc. (Brocade)
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "bluca", with
commit author "Luca Boccassi <luca.boccassi@gmail.com>" or
"Luca Boccassi <lboccass@brocade.com>", are copyright of Brocade.
This permission to relicense includes all past, present and future
contributions of Brocade employees.

Luca Boccassi
Software Engineer, Brocade Communications Systems Inc.
2016-05-16
